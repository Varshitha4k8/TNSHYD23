package p1;

public class A {
	void display() {
		System.out.println("default");
	}
	public static void main(String args[]) {
		 A obj=new A();
		 obj.display();
		
	}

}
